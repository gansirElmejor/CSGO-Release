import java.util.ArrayList;
import java.util.concurrent.ArrayBlockingQueue;

import javax.swing.JLabel;

import java.lang.Math;
public class Player extends Character {
    private Timer t;
    private ArrayBlockingQueue<TimedAction> waitList;

    private String IP;
    private String name;
    private NetworkHandler networkHandler;
    private int atkMultiplier;
    private int spdMultiplier;
    private int atkBuff;
    private int spdBuff;
    private int Id;
    private int x;
    private int y;
    private int xVelocity; //control movement but aren't changed normally
    private int yVelocity; //control movement but aren't changed normally
    private int hp;
    private String bulletID;
    private int pointingDirection;
    private boolean spectator = false;
    
    private boolean isBurned;
    private boolean isInvulnerable;
    private boolean isInvisible;
    private boolean isStunned;
    private boolean isFrozen;
    private boolean isNeutralized;
    private Thread timerThread;
    private Boolean hitAnimate = false;
    private ArrayList<Player> playerList;
    private JLabel namLabel = null;
    
    Player(String name, String IP, NetworkHandler networkHandler, int Id, int x, int y, String bulletID, ArrayList<Player> playerList) {
        super(bulletID); //Load Known-character info from Character class which from characterConst
        this.waitList = new ArrayBlockingQueue<TimedAction>(100);
        this.spdMultiplier = 1;
        this.atkMultiplier = 1;
        this.atkBuff = 0;
        this.spdBuff = 0;
        this.name = name;
        this.IP = IP;
        this.networkHandler = networkHandler;
        this.Id = Id;
        this.x = x;
        this.y = y;
        this.bulletID = bulletID;
        this.hp = super.getMaxHp();
        this.playerList = playerList;
        timerThread = new Thread(new Timer(atkMultiplier, spdMultiplier,waitList),"timer");
        timerThread.start();
    }

    public void setSpectator(boolean yn){
        spectator=yn;
    }
    public boolean isSpectator(){
        return spectator;
    }
    
    public void setNameLabel(JLabel namLabel) {
        this.namLabel = namLabel;
    }
    public JLabel getNameLabel() {
        return this.namLabel;
    }
    public int getAtk() {
        return super.getDamagePerShot() * atkMultiplier + atkBuff;
    }
    private double distance(int victimId) {
        for (int i = 0; i < playerList.size(); i++) {
            if (playerList.get(i).Id == victimId) {
                return Math.sqrt((x - playerList.get(i).x) * (x - playerList.get(i).x) + (y - playerList.get(i).y) * (y - playerList.get(i).y)); 
            } 
        }
        return 0;
    }
    public void useQ () {
        if (bulletID == "Hotshot") {
            networkHandler.burnPlr("VictimID");
        } else if  (bulletID == "Bulky") {
            networkHandler.invulnerble(Integer.toString(Id), 5000);
        } else if (bulletID == "Stronk") {
            atkMultiplier = 2;
            waitList.add(new TimedAction(8000, 'a'));
        } else if (bulletID == "Dash") {
            spdMultiplier = 10;
            waitList.add(new TimedAction(500, 's'));
            networkHandler.invulnerble(bulletID, 500);
            
        } else if (bulletID == "Hook") {
            atkBuff = 6;
            for (int i = 0; i < playerList.size(); i++) {
                if (Math.sqrt((x - playerList.get(i).x) * (x - playerList.get(i).x) + (y - playerList.get(i).y) * (y - playerList.get(i).y)) <= 15) {
                    networkHandler.dmg(Integer.toString(playerList.get(i).Id),getAtk());
                }
            }
            atkBuff = 0;
        } else if (bulletID == "Ghost") {
            networkHandler.invisible(Integer.toString(Id), 5500);
        } else if (bulletID == "Freezer") {
            //actually I forgot the details about this one
        } else if (bulletID == "Landmine") {
            
        } else if (bulletID == "Melee") {
        
        } else if (bulletID == "Neutralizer") {
        
        } else if (bulletID == "Joker") {
        
        }
    }
    public void useE () {
        if (bulletID == "Hotshot") {
            
        } else if  (bulletID == "Bulky") {
        
        } else if (bulletID == "Stronk") {
        
        } else if (bulletID == "Dash") {
        
        } else if (bulletID == "Hook") {
        
        } else if (bulletID == "Ghost") {
        
        } else if (bulletID == "Freezer") {
        
        } else if (bulletID == "Landmine") {
        
        } else if (bulletID == "Melee") {
        
        } else if (bulletID == "Neutralizer") {
        
        } else if (bulletID == "Joker") {
        
        }
    }
    
    public int getBulletIDInteger(String bulletID){
        if(bulletID=="Standard"){ return 0;}
        else if(bulletID=="Hotshot"){return 1;}
        else if(bulletID=="Bulky"){return 2;}
        else if(bulletID=="Stronk"){return 3;}
        else if(bulletID=="Dash"){return 4;}
        else if(bulletID=="Hook"){return 5;}
        else if(bulletID=="Ghost"){return 6;}
        else if(bulletID=="Freezer"){return 7;}
        else if(bulletID=="Landmine"){return 8;}
        else if(bulletID=="Melee"){return 9;}
        else if(bulletID=="Neutralizer"){return 10;}
        else if(bulletID=="Joker"){return 11;}
        return 0;
    }
    
    public String getIP() {
        return this.IP;
    }

    public int getId() {
        return this.Id;
    }

    public int getX() {
        return this.x;
    }

    public int getY() {
        return this.y;
    }

    public int getHp() {
        return this.hp;
    }

    public String getBulletID() {
        return this.bulletID;
    }

    public void setXY(int x, int y) {
        this.x = x;
        this.y = y;
    }
    public void moveConstantX(int x) {
        this.x+=x;
    }
    public void moveConstantY(int y) {
        this.y+=y;
    }
    public void moveX(double FB){ 
        this.x+=Math.round(FB*super.getSpeed());
        //SEND MOVEMENT UPDATE TO SERVER //NoNo, Server come get your movement (Network handler sends movement based on tick time so equvalent to server come get your movement)
    }
    public void moveY(double FB){ 
        this.y+=Math.round(FB*super.getSpeed());
        //SEND MOVEMENT UPDATE TO SERVER 
         //NoNo, Server come get your movement (Network handler sends movement based on tick time so equvalent to server come get your movement)
    }

    public String getName() {
        return this.name;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }
    public void reduceHp(int dropped){
        this.hp-=dropped;
    }

    public void setDirection(int pointingDirection) {
        this.pointingDirection = pointingDirection;
    }
    public void setHitAnimate(Boolean val) {
        this.hitAnimate = val;
    }
    public Boolean isHitAnimate() {
        if (this.hitAnimate) {
            this.hitAnimate = false;
            return true;
        }
        return false;
    }
    public int getDirection() {
        return this.pointingDirection;
    }
}
class TimedAction {
    int timeMil;
    char action;
    TimedAction(int t, char a) {
        this.timeMil = (int)System.currentTimeMillis() + t;
        this.action = a;
    }
    public int getTime() {
        return timeMil;
    }
    public char getAction() {
        return action;
    }
}
class Timer extends Thread{
    int atkM;
    int spdM;
    ArrayBlockingQueue<TimedAction> waitList;
    
    Timer(int atkM, int spdM, ArrayBlockingQueue<TimedAction> waitList){
        this.atkM = atkM;
        this.spdM = spdM;
        this.waitList = waitList;
    }
    @Override
    public void run() {
        while (!waitList.isEmpty()) {
            
            if (System.currentTimeMillis() >= waitList.peek().getTime()) {
                if (waitList.peek().getAction() == 'a') {
                    atkM = 1;
                } else if (waitList.peek().getAction() == 's') {
                    spdM = 1;
                }
                waitList.remove();
            }
        }
    }
}

