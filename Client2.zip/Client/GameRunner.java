import java.util.ArrayList;

public class GameRunner{
    static ArrayList<Player> playerList = new ArrayList<Player>();
    static NetworkHandler networkHandler;
    public static void main(String[] args){
        networkHandler = new NetworkHandler(playerList);
        //Player localPlayer = new Player(null, null, networkHandler, 0, 0, 0, null, playerList);
        StartFrame startFrame = new StartFrame();
        startFrame.initialize(networkHandler,playerList);
    }
}
