public class Bullet {
    private double x;
    private double y;
    private Boolean IsOut = false;
    private double dirX;
    private double dirY;
    private double maxDist;
    private Boolean networkOwnership = false;
    private int block;
    Bullet(int x, int y, double dirX, double dirY, int perTick, double maxDist, Boolean networkOwnership) {
        this.networkOwnership = networkOwnership;
        this.x = x;
        this.y = y;
        this.maxDist = maxDist;
        this.dirX = (double)perTick / Math.sqrt(dirX * dirX + dirY * dirY) * dirX;
        this.dirY = this.dirX / dirX * dirY;
    }
    public double getX() {return this.x;}
    public double getY() {return this.y;}
    
    public void updateBullet() {
        this.x = this.x + this.dirX;
        this.y = this.y + this.dirY;
        maxDist -= Math.sqrt(dirX * dirX + dirY * dirY);
        if(maxDist<0){
            this.IsOut = true;
        }
        if (this.x > 5000 || this.x < -5000 || this.y > 5000 || this.y < -5000) {
            this.IsOut = true;
        }
        if (this.block == 4 || this.block == 2) {
            this.IsOut = true;
        }
    }
    public void setIsOut(boolean io) {
        this.IsOut = io;
    }
    public Boolean getIsOut() {
        return this.IsOut;
    }
    public Boolean netIsOwned() {return this.networkOwnership;}
}
