//here goes all of the graphics stuff
//most of the game-based stuff is from this
import javax.imageio.ImageIO;
//here goes all of the graphics stuff
//most of the game-based stuff is from this
import java.io.File;
import java.io.IOException;

import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.ArrayBlockingQueue;
class GameFrame extends JFrame{
    
    private Image[] spriteSheet=new Image[17];
    private ClientNetworkConst Const = new ClientNetworkConst();
    private ImagePanel myFrame;
    private Container container;
    private GridBagConstraints constraint;
    private NetworkHandler networkHandler;
    private LocalMovementHandler movementHandler;
    private HashMap<String,Boolean> movementMap = new HashMap<String,Boolean>();
    private MyKeyListener keyListener;
    private MyMouseListener mouseListener;
    private int[][] map;
    
    private Player player;
    private ArrayList<Player> opponents;
    private ArrayList<Bullet> bullets = new ArrayList<Bullet>();

    private final int[] Qdelays=new int[]{0,3,5,10,5,1,10,7,5,5,25};
    private final int Edelays=5;

    private long QLastUsed=0;
    private long ELastUsed=0;
    private long lastShot=0;
    GameFrame(NetworkHandler networkHandler, ArrayList<Player> playerList, int spawnX, int spawnY, String bulletID, String name, int selfID, int[][] map) {
        this.opponents = playerList;
        this.networkHandler = networkHandler;
        this.map = map;
        this.player = new Player(name, "", networkHandler, selfID, spawnX, spawnY, bulletID, opponents);
        movementMap.put("w", false);
        movementMap.put("a", false);
        movementMap.put("s", false);
        movementMap.put("d", false);
        this.movementHandler = new LocalMovementHandler(movementMap);
        Thread movementThread = new Thread(movementHandler,"LocalMovement");
        movementThread.start();
        
    }

    public class ImagePanel extends JPanel {

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            //450 is the radius of viewing
             int minXBlock=(player.getX()-450)/100;
            int minYBlock=(player.getY()-450)/100;
            int maxXBlock=(player.getX()+450)/100;
            int maxYBlock=(player.getY()+450)/100;

            for(int x=minXBlock;x<=maxXBlock;x++){
                for(int y=minYBlock;y<=maxYBlock;y++){
                    if(x>=0&&y>=0&&x<27&&y<27){                       
                        int xPosTopBound=x*100-player.getX()+450;
                        int yPosTopBound=y*100-player.getY()+450;
                        g.drawImage(spriteSheet[map[x][y]], xPosTopBound, yPosTopBound, 100,100,null);
                    }
                }
            }
            if(player.isSpectator()==false){
                g.fillOval(450-25, 450-25, 50,50);
            }
            //drawing character
            for(int x=0;x<opponents.size();x++){
                Player oppnent = opponents.get(x);
                if(oppnent.isSpectator()==false){
                    if(map[oppnent.getX()/100][oppnent.getY()/100]!=1 || -100 <= oppnent.getX() - player.getX() && oppnent.getX() - player.getX() <= 100 && -100 <= oppnent.getY() - player.getY() && oppnent.getY() - player.getY() <= 100){
                        if (oppnent.isHitAnimate() || oppnent.isSpectator()) {
                            g.setColor(Color.RED);
                        }
                        g.fillOval(oppnent.getX()-player.getX()+450-25, oppnent.getY()-player.getY()+450-25, 50,50);
                        JLabel namLabel = oppnent.getNameLabel();
                        if (namLabel == null) {
                            namLabel = new JLabel(oppnent.getName());
                            namLabel.setBounds(oppnent.getX()-player.getX()+450-25, opponents.get(x).getY()-player.getY()+450-25, 100,50);
                            container.add(namLabel);
                            namLabel.setVisible(true);
                            namLabel.setForeground(Color.WHITE);
                            oppnent.setNameLabel(namLabel);
                        } else {
                            namLabel.setBounds(oppnent.getX()-player.getX()+450-25, opponents.get(x).getY()-player.getY()+450-25, 100,50);
                        }
                        
                    }
                }
            }
            //drawBullet
            int x=0;
            int currentX, currentY;
            while(bullets.size()>x) {
                g.setColor(Color.RED);
                g.fillOval((int)bullets.get(x).getX()-player.getX() + 450, (int)bullets.get(x).getY()-player.getY() + 450, 10, 10);
               
                bullets.get(x).updateBullet();
                currentX = (int)(bullets.get(x).getX());
                currentY = (int)(bullets.get(x).getY());
                
                if (map[currentX / 100][currentY / 100] == 4 || map[currentX / 100][currentY / 100] == 2) {
                    bullets.get(x).setIsOut(true);
                }
                if (bullets.get(x).netIsOwned()) {
                for (int i=0; i<opponents.size(); i++) {
                    Player opponent = opponents.get(i);
                    int oppX = opponent.getX();
                    int oppY = opponent.getY();
                    if (Math.sqrt((oppX-bullets.get(x).getX())*(oppX-bullets.get(x).getX()) + (oppY-bullets.get(x).getY())*(oppY-bullets.get(x).getY())) <= 25) {
                        opponent.setHitAnimate(true);
                        System.out.println("Damaged a player"); 
                        bullets.get(x).setIsOut(true);
                        networkHandler.dmg(opponent.getId()+"", opponent.getAtk());
                    }
                }
                }
                if (bullets.get(x).getIsOut()) {
                    bullets.remove(x);
                }
                x++;
            }
        }
        
    }
  
  public void initialize(){
      //get all the sprites from their files
        try{
            Image img = ImageIO.read(new File("./ground.png"));
            Image resized = img.getScaledInstance(100, 100, Image.SCALE_DEFAULT);
            spriteSheet[0] = resized;
        } catch (IOException e){
            System.out.println("could not upload sprite");
        }
        try{
            Image img = ImageIO.read(new File("./grass.png"));
            Image resized = img.getScaledInstance(100, 100, Image.SCALE_DEFAULT);
            spriteSheet[1] = resized;
        } catch (IOException e){
            System.out.println("could not upload sprite");
        }
      try{
        Image img = ImageIO.read(new File("./wall.png"));
        Image resized = img.getScaledInstance(100, 100, Image.SCALE_DEFAULT);
        spriteSheet[2] = resized;
        } catch (IOException e){
            System.out.println("could not upload sprite");
        }
      try{
        Image img = ImageIO.read(new File("./water.png"));
        Image resized = img.getScaledInstance(100, 100, Image.SCALE_DEFAULT);
        spriteSheet[3] = resized;
        } catch (IOException e){
            System.out.println("could not upload sprite");
        }
      try{
        Image img = ImageIO.read(new File("./border.png"));
        Image resized = img.getScaledInstance(100, 100, Image.SCALE_DEFAULT);
        spriteSheet[4] = resized;
        } catch (IOException e){
            System.out.println("could not upload sprite");
        }
      
    // initialization of frame
      
        int startingScreenWidth = 900;
        int startingScreenHeight = 900;
        myFrame = new ImagePanel();
        this.setContentPane(myFrame);
        
      
        this.setSize(startingScreenWidth, startingScreenHeight); // 60% of a 1920x1080 resolution
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        myFrame.setMinimumSize(new Dimension(startingScreenWidth, startingScreenHeight));

      
      //setup of content pane which stores visuals
        container = this.getContentPane();
        container.setLayout(null);
        
        constraint = new GridBagConstraints();
        constraint.insets = new Insets(10,10,10,10); // top bottom left right (external padding)
        this.addKeyListener(new MyKeyListener());
        this.addMouseListener(new MyMouseListener());
        this.setVisible(true);
        myFrame.setVisible(true);
        Thread rePainterThread = new Thread(new Repainter(myFrame,networkHandler),"Repainter");
        rePainterThread.start();
        
  }
        //draw stuff on the screen, add blocks idk but this is it this is the game

class Repainter extends Thread{
    ImagePanel theFrame;
    NetworkHandler networkHandler;
    ArrayBlockingQueue<String> resQueue;
    ClientNetworkConst Const = new ClientNetworkConst();
    Repainter(ImagePanel theFrame,NetworkHandler networkHandler) {
        this.theFrame = theFrame;
        this.networkHandler = networkHandler;
        this.resQueue = networkHandler.getresQueue();
    }

    private Player getOpponentById(int Id) {
        for (int i=0; i<opponents.size(); i++) {
            Player p = opponents.get(i);
            if (opponents.get(i).getId() == Id) {
                return p;
            }
        }
        return null;
    }

    private Player createPlayer(int Id, int x, int y, int pointingDirection, String bulletID, String plrName) {
        Player newPlr = new Player(plrName, "", networkHandler, Id, x, y, bulletID, opponents);
        synchronized(opponents) {
            opponents.add(newPlr);
        }
        return newPlr;
    }
    private void removePlayerById(int Id) {
        Player plr = getOpponentById(Id);
        if (plr != null) {
            synchronized(opponents) {
                opponents.remove(plr);
            }
        }
    }

    private void updatePlayer(Player player,int x,int y,int pointingDirection) {
        synchronized(player) {
            player.setDirection(pointingDirection);
            player.setXY(x, y);
        }
    }

    public void processRes(String res) {
        String[] firstSplit = res.split(Const.getFstRegex());
        if (firstSplit[0].equals(Const.getReqNorm())) {//PlayerPositions
            for (int i=1;i<firstSplit.length;i++) {
                String[] plrStat = firstSplit[i].split(Const.getSecRegex());
                int Id = Integer.parseInt(plrStat[0]);
                if (Id == player.getId()) {
                    continue; //because this is localplayer himself
                }
                int x = Integer.parseInt(plrStat[1]);
                int y = Integer.parseInt(plrStat[2]);
                int pointingDirection = Integer.parseInt(plrStat[3]);
                String bulletID = plrStat[4];
                String plrName = plrStat[5];
                Player plr = getOpponentById(Id);
                if(plr == null) { //If player does not exist
                    plr = createPlayer(Id, x, y, pointingDirection, bulletID, plrName);
                    continue;
                }
                updatePlayer(plr,x,y,pointingDirection);
            }
        } else if (firstSplit[0].equals(Const.getKick())) {
            removePlayerById(Integer.parseInt(firstSplit[1]));
        } else if (firstSplit[0].equals(Const.getReqAttack())) {
            String[] secSplit = firstSplit[1].split(Const.getSecRegex());
            int victimeID = Integer.parseInt(secSplit[0]);
            int lostHp = Integer.parseInt(secSplit[1]);
            if (victimeID == player.getId()) {
                player.setHp(player.getHp() - lostHp);
            }
            if (player.getHp() <= 0) {
                System.out.println("Player Died!!!");;
                player.setSpectator(true);
                networkHandler.reportDeath();
            }
        } else if (firstSplit[0].equals(Const.getReqRay())) {
            //BulletAnimation
            int bulletSpeed = 30;
            for (int i=1; i<firstSplit.length; i++) {
                String[] secSplit = firstSplit[i].split(Const.getSecRegex());
                int attackerID = Integer.parseInt(secSplit[2]);
                if (attackerID == player.getId()) {System.out.println("No self"); continue;};
                int clickX = Integer.parseInt(secSplit[0]);
                int clickY = Integer.parseInt(secSplit[1]);
                Player attacker = getOpponentById(attackerID);
                if (attacker == null) {continue;}
                int startX = attacker.getX();
                int startY = attacker.getY();
                Boolean networkOwnerShip = false; //This must be false, because it's not local bullet
                System.out.println(res);
                synchronized(bullets) {
                    bullets.add(new Bullet(startX,startY,clickX - startX,clickY - startY, bulletSpeed, 5000,networkOwnerShip));
                }
                
            }
           
        } else if (firstSplit[0].equals(Const.getReqChangeMap())) {
            int changeRow = Integer.parseInt(firstSplit[1]);
            System.out.println("here");
            for (int i = changeRow; i <= 26 - changeRow; i++) {
                map[i][changeRow] = 4;
                map[i][26 - changeRow] = 4;
                map[changeRow][i] = 4;
                map[26 - changeRow][i] = 4;
            }
            //synchronized (player) {
            if (player.getX() < (1 + changeRow) * 100 + 5) {
                player.moveConstantX(100);
            } else if (player.getX() > (26 - changeRow) * 100 - 5) {
                player.moveConstantX(-100);
            }
            if (player.getY() < (1 + changeRow) * 100 + 5) {
                player.moveConstantY(100);
            } else if (player.getY() > (26 - changeRow) * 100 - 5) {
                player.moveConstantY(-100);
            }
            //}
        }
    }

    @Override
    public void run() {
        while(true){
            //pause thread execution for the duration of one video frame
            try{Thread.sleep(Const.getTick());} catch (Exception exc){}
            myFrame.repaint();
            if (resQueue.isEmpty()) {continue;}
            processRes(resQueue.remove());
        }
    }

}
    

    private class LocalMovementHandler extends Thread{
        HashMap<String,Boolean> movementMap;
        LocalMovementHandler(HashMap<String,Boolean> movementMap) {
            this.movementMap = movementMap;
        }
        @Override
        public void run() {
            while (true) {
                Boolean moved = false;
                try{Thread.sleep(Const.getTick());} catch (Exception exc){}
                if ((map[player.getX()/100][(player.getY()-player.getSpeed())/100]!=2 && map[player.getX()/100][(player.getY()-player.getSpeed())/100]!=4) && movementMap.get("w")) {
                    if(map[player.getX()/100][(player.getY()-player.getSpeed())/100]==3){
                        player.moveY(-0.7);
                    } else{
                        player.moveY(-1.0);
                    }
                    
                    moved = true;
                }
                if((map[(player.getX()-player.getSpeed())/100][player.getY()/100]!=2 && map[(player.getX()-player.getSpeed())/100][player.getY()/100]!=4) && movementMap.get("a")){
                    if(map[player.getX()/100][(player.getY()-player.getSpeed())/100]==3){
                        player.moveX(-0.7);
                    } else{
                        player.moveX(-1.0);
                    }
                    moved = true;
                }
                if((map[player.getX()/100][(player.getY()+player.getSpeed())/100]!=2 && map[player.getX()/100][(player.getY()+player.getSpeed())/100]!=4) && movementMap.get("s")){
                    if(map[player.getX()/100][(player.getY()-player.getSpeed())/100]==3){
                        player.moveY(0.7);
                    } else{
                        player.moveY(1.0);
                    }
                    moved = true;
                }
                if((map[(player.getX()+player.getSpeed())/100][player.getY()/100]!=2 && map[(player.getX()+player.getSpeed())/100][player.getY()/100]!=4) && movementMap.get("d")){
                    if(map[player.getX()/100][(player.getY()-player.getSpeed())/100]==3){
                        player.moveX(0.7);
                    } else{
                        player.moveX(1.0);
                    }
                    moved = true;
                }
                if (moved && (player.isSpectator() == false)) {
                    networkHandler.reportMovement(player.getX(),player.getY(),player.getDirection());
                }
            }
        }
    }
        
  //}
    private class MyKeyListener implements KeyListener{      
        // method to process key pressed events (when a key goes down, i.e. immediately)
        
        @Override
        public void keyPressed(KeyEvent e){
            int key = e.getKeyChar(); //use this for movement
            if(key == 'w' || key == 'W'){
                if ((map[player.getX()/100][(player.getY()-player.getSpeed())/100]!=2 && map[player.getX()/100][(player.getY()-player.getSpeed())/100]!=4)) {
                    movementMap.put("w", true);
                }     
            }
            else if(key == 'a' || key == 'A'){
                if(map[(player.getX()-player.getSpeed())/100][player.getY()/100]!=2 && map[(player.getX()-player.getSpeed())/100][player.getY()/100]!=4){
                    movementMap.put("a", true);
                }
            }
            else if(key=='s' || key == 'S'){
                if(map[player.getX()/100][(player.getY()+player.getSpeed())/100]!=2 && map[player.getX()/100][(player.getY()+player.getSpeed())/100]!=4){
                    movementMap.put("s", true);
                }
            }
            else if(key== 'd' || key == 'D'){
                if(map[(player.getX()+player.getSpeed())/100][player.getY()/100]!=2 && map[(player.getX()+player.getSpeed())/100][player.getY()/100]!=4){
                    movementMap.put("d", true);
                }
            }
            else if(key==81){
                if(System.currentTimeMillis()-QLastUsed>Qdelays[player.getBulletIDInteger(player.getBulletID())]){
                    player.useQ();//not the right method
                    QLastUsed=System.currentTimeMillis();
                }
                
            }
            else if(key==69){
                if(System.currentTimeMillis()-ELastUsed>Edelays){
                    player.useE();//not the right method
                    ELastUsed=System.currentTimeMillis();
                }
            }
        }
        
        @Override
        public void keyReleased(KeyEvent e){
            int key = e.getKeyChar();
            if(key == 'w' || key == 'W'){
                movementMap.put("w", false);   
            }
            else if(key == 'a' || key == 'A'){
                movementMap.put("a", false);
            }
            else if(key=='s' || key == 'S'){
                    movementMap.put("s", false);
                
            }
            else if(key== 'd' || key == 'D'){
                    movementMap.put("d", false);
            }
        }       
        // method to process key typed events (only typeable/printable keys)
        @Override
        public void keyTyped(KeyEvent e){        // MUST be implemented even if not used!
        }        
    }
//--------------------
    // mouse inputs, remember to add listener to frame
    private class MyMouseListener implements MouseListener{
        public void mouseClicked(MouseEvent e){
            if(System.currentTimeMillis()-lastShot>0.2 && player.isSpectator()==false){
                lastShot=System.currentTimeMillis();
                int bulletSpeed = 30;
                int startX=player.getX();
                int startY=player.getY();
                double clickX=e.getX()+player.getX() - 450 - 12;//translate positions on the screen to universal coordinates
                double clickY=player.getY() + e.getY() - 450 - 42;
                System.out.println(player.getId());
                networkHandler.openFire((int)clickX, (int)clickY, player.getId());
                Boolean networkOwnerShip = true;
                synchronized(bullets) {
                    bullets.add(new Bullet(startX,startY,clickX - startX, clickY - startY,bulletSpeed, 5000,networkOwnerShip));  
                }
            }
        }
        public void mousePressed(MouseEvent e){   // MUST be implemented even if not used!
        }
        public void mouseReleased(MouseEvent e){  // MUST be implemented even if not used!
        }
        public void mouseEntered(MouseEvent e){   // MUST be implemented even if not used!
        }
        public void mouseExited(MouseEvent e){    // MUST be implemented even if not used!
        }
    }
}
