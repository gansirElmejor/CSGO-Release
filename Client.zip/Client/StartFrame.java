//herere goes all of the graphics stuff
//most of the game-based stuff is from this
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;

import javax.swing.*;
public class StartFrame{

    private JFrame myFrame;
    private Container container;
    private GridBagConstraints constraint;
    private ArrayBlockingQueue<String> resQueue;
    private JTextField nameInput;
  
    private JList characterList;
    private JScrollPane characterScrollPane;
    private DefaultListModel characterListModel;
    private NetworkHandler networkHandler;
    private JButton startButton;

    //private MyKeyListener keyListener;
    //private MyMouseListener mouseListener;
    
    public class ImagePanel extends JPanel {
        private Image myImage;

        public ImagePanel(String imagePath) {
            myImage = new ImageIcon(imagePath).getImage();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (myImage != null) {
                g.drawImage(myImage, 0, 0, getWidth(), getHeight(), this);
            }
        }
    }
  
    public void initialize(NetworkHandler networkHandler,ArrayList<Player> playerList) {
        this.networkHandler = networkHandler;
        this.resQueue = networkHandler.getresQueue();
        //ImagePanel myImage = new ImagePanel(image name here);
        // initialization of frame
        int startingScreenWidth = 600;
        int startingScreenHeight = 525;
        myFrame = new JFrame("CS GO");
        //myFrame.setContentPane(myImage);
        
    
        myFrame.setSize(startingScreenWidth, startingScreenHeight); // 60% of a 1920x1080 resolution
        myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        myFrame.setResizable(false);
        myFrame.setMinimumSize(new Dimension(startingScreenWidth, startingScreenHeight));

      //setup of content pane which stores visuals
        container = myFrame.getContentPane();
        container.setLayout(null);
        
        constraint = new GridBagConstraints();
        constraint.insets = new Insets(10,10,10,10); // top bottom left right (external padding)

        //add stuff to the starting screen

        JLabel labelId = new JLabel("Name:");
        container.add(labelId);
        labelId.setFont(new Font("among us", Font.PLAIN, 24));
        labelId.setBounds(175,60,100,40);
        
        nameInput = new JTextField("",16);
        nameInput.setFont(new Font("among us", Font.PLAIN, 24));
        container.add(nameInput);
        nameInput.setBounds(260,60,160,40);
        //nameInput.getText() gives text in the box


        JLabel labelId1 = new JLabel("Character:");
        container.add(labelId1);
        labelId1.setFont(new Font("sus", Font.PLAIN, 24));
        labelId1.setBounds(135,120,150,40);

      
        characterListModel = new DefaultListModel();
        characterList = new JList(characterListModel); //boxList has type Object[] (in this case, String)
        characterList.setLayoutOrientation(JList.VERTICAL);
        characterList.setVisibleRowCount(-1);
        characterListModel.addElement("Standard");
        characterListModel.addElement("Bulky");
        characterListModel.addElement("Stronk");
        characterListModel.addElement("Dash");
        characterListModel.addElement("Hook");
        characterListModel.addElement("Melee");
        characterListModel.addElement("Neutralizer");
        
        characterScrollPane = new JScrollPane(characterList);
        characterScrollPane.setBounds(260,120,160,200);
        
        container.add(characterScrollPane, constraint);

    
        //container.add(boxScrollPane, constraint);
        //this adds stuff to the thing i think
        JLabel networkError = new JLabel("Server ip not reachable, check network settings!");
        networkError.setBounds(165,420,250,40);
        JLabel charCountError = new JLabel("Name must have at least 1 character.");
        charCountError.setBounds(165,420,250,40);
        JLabel symbolError = new JLabel("Name must not contain spaces or the '&' symbol.");
        symbolError.setBounds(135,420,280,40);
        JLabel nameTakenError = new JLabel("Name already taken.");
        nameTakenError.setBounds(175,420,240,40);
        JLabel charSelectError=new JLabel("please select a character.");
        charSelectError.setBounds(170,420,240,40);
        //container.add(boxScrollPane, constraint);
        //this adds stuff to the thing i think

        //COMMUNICATE WITH SERVER TO GET PLAYER COUNT AND PLAYER NAME LIST
        //int playercount=server.getPlayerCount();//REWRITE THIS LINE
        //String[] namelist=new String[playercount];
        //for(int x=0;x<playercount;x++){
        //    namelist[x]=server.getPlayerName(0);//REWRITE THIS LINE
        //}
      
        startButton = new JButton("Begin");
        startButton.setBounds(120,340,300,60);//man idk what the dimensions should be
        startButton.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent e) {
                //do the checks to start the game
                charCountError.setVisible(false);
                symbolError.setVisible(false);
                nameTakenError.setVisible(false);
                networkError.setVisible(false);
                container.add(networkError);
                String playerName=nameInput.getText();
                if(playerName.indexOf(' ')>=0 || playerName.indexOf('&')>=0){
                    container.add(symbolError);
                    symbolError.setVisible(true);
                }
                else if(playerName.length()<1){
                    container.add(charCountError);
                    charCountError.setVisible(true);
                }
                else{
                    Object[] chosencharacterprecheck= characterList.getSelectedValuesList().toArray();
                    
                    if(chosencharacterprecheck.length==0){
                        container.add(charSelectError);
                        charCountError.setVisible(true);
                    }
                    else{
                        String chosencharacter=(String)chosencharacterprecheck[0];
                        
                        //set character
                        //NETWORK: LOGIN REQUEST
                        networkHandler.login(playerName, chosencharacter);
                        // //Respond check
                        while (true) {
                            if (resQueue.isEmpty()) {
                                try{TimeUnit.MILLISECONDS.sleep(500);} catch(Exception err) {err.printStackTrace();};
                                continue;
                            }
                            String msg = resQueue.remove();
                            System.out.println(msg);
                            if (msg.split("&")[0].equals("201")) {
                                // Do map stuff here as well
                                int selfID = Integer.parseInt(msg.split("&")[1].split(" ")[3]); // get the assigned ID from server
                                System.out.println("game initializing "+ selfID);
                                GameFrame gameFrame = new GameFrame(networkHandler,playerList,50+Integer.parseInt(msg.split("&")[1].split(" ")[0]) * 100,50+Integer.parseInt(msg.split("&")[1].split(" ")[1])*100,chosencharacter,playerName,selfID,networkHandler.decodeMap(msg.split("&")[1].split(" ")[2])); //where to spawn, change this later
                                gameFrame.initialize();
                                myFrame.setVisible(false);
                                break;
                             } else if (msg.split("&")[0].equals("404")) {
                                container.add(networkError);
                                networkError.setVisible(true);
                                break;
                             }
                         }
                        
                    }
                    
                }
              
            }
        });
            
        container.add(startButton, constraint);
        myFrame.setVisible(true);
  }
   /* public class MyKeyListener implements KeyListener{      
        // method to process key pressed events (when a key goes down, i.e. immediately)
        public void keyPressed(KeyEvent e){
            int key = e.getKeyCode(); //use this for movement
        }
        // method to process key released events (when a key goes up)
        public void keyReleased(KeyEvent e){     // MUST be implemented even if not used!
        }       
        // method to process key typed events (only typeable/printable keys)
        public void keyTyped(KeyEvent e){        // MUST be implemented even if not used!
        }        
    }
//--------------------
    // mouse inputs

    
    public class MyMouseListener implements MouseListener{
        public void mouseClicked(MouseEvent e){
            //e.getX()
            //e.getY()
        }
        public void mousePressed(MouseEvent e){   // MUST be implemented even if not used!
        }
        public void mouseReleased(MouseEvent e){  // MUST be implemented even if not used!
        }
        public void mouseEntered(MouseEvent e){   // MUST be implemented even if not used!
        }
        public void mouseExited(MouseEvent e){    // MUST be implemented even if not used!
        }
    }
    */
}