import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.concurrent.ArrayBlockingQueue;

public class NetworkHandler{
    ClientNetworkConst Const = new ClientNetworkConst();
    ArrayList<Player> playerList;
    ArrayBlockingQueue<String> reqQueue = new ArrayBlockingQueue<String>(Const.getMaxNetReq());
    ArrayBlockingQueue<String> resQueue = new ArrayBlockingQueue<String>(Const.getMaxNetReq());
    ClientComm client = new ClientComm(reqQueue, resQueue);
    NetworkHandler(ArrayList<Player> playerList) {
        this.playerList = playerList;
        Thread netThread = new Thread(new NetworkUpdater(client, reqQueue, resQueue),"ClientNetworkHandling");
        netThread.start();
    }

    public ArrayBlockingQueue<String> getresQueue() {return this.resQueue;}

    public void login(String userName, String characterID) { //Ensure no space and "&" in username and characterID
        String request = Const.getReqLogin()+Const.getFstRegex()+userName+Const.getSecRegex()+characterID;
        reqQueue.add(request);
    }
    public void reportMovement(int x, int y, int pointingDirection) {
        String request = Const.getReqNorm()+Const.getFstRegex()+x+Const.getSecRegex()+y+Const.getSecRegex()+pointingDirection;
        reqQueue.add(request);
    }
    public void dmg(String VictimID, int dmg) {
        String request = Const.getReqAttack()+Const.getFstRegex()+VictimID+Const.getSecRegex()+dmg;
        reqQueue.add(request);
    }
    public void openFire(int x, int y, int selfID) {
        String request = Const.getReqRay()+Const.getFstRegex()+x+Const.getSecRegex()+y+Const.getSecRegex()+selfID;
        reqQueue.add(request);
    }
    public void reportDeath() {
        String request = Const.getKick();
        reqQueue.add(request);
    }
    public void castBullet(int bulletEndX,int bulletEndY) {
        String request = Const.getReqRay()+Const.getFstRegex()+bulletEndX+Const.getSecRegex()+bulletEndY;
        reqQueue.add(request);
    }
    public void burnPlr(String VictimId) {
        String request = Const.getReqBurn()+Const.getFstRegex()+VictimId;
        reqQueue.add(request);
    }
    public void invulnerble(String VictimId, int Time){
        String request = Const.getReqInvulnerable()+Const.getFstRegex()+VictimId;
        reqQueue.add(request);
    }
    public void invisible(String VictimId, int Time){
        String request = Const.getReqInvisible()+Const.getFstRegex()+VictimId+Const.getSecRegex()+Time;
        reqQueue.add(request);
    }
    public void frozen(String VictimId, int Time){
        String request = Const.getReqFrozen()+Const.getFstRegex()+VictimId+Const.getSecRegex()+Time;
        reqQueue.add(request);
    }
    public void stun(String VictimId, int Time){
        String request = Const.getReqStun()+Const.getFstRegex()+VictimId+Const.getSecRegex()+Time;
        reqQueue.add(request);
    }
    public void nutralize(String VictimId, int Time){
        String request = Const.getReqNutralize()+Const.getFstRegex()+VictimId+Const.getSecRegex()+Time;
        reqQueue.add(request);
    }

    public int[][] decodeMap(String mapStr) {
        String[] lintSplit = mapStr.split("l");
        String[][] stringMap=new String[27][27];
        for(int x=0;x<27;x++){
            stringMap[x]=lintSplit[x].split("");
        }
        int[][] finalmap=new int[27][27];
        for(int x=0;x<27;x++){
            for(int y=0;y<27;y++){
                finalmap[x][y]=Integer.parseInt(stringMap[x][y]);
            }
        }

        
        
        
        return finalmap;
    }
}

class NetworkUpdater extends Thread {
    ClientNetworkConst Const = new ClientNetworkConst();
    ClientComm client;
    ArrayBlockingQueue<String> reqQueue;
    ArrayBlockingQueue<String> resQueue;
    NetworkUpdater(ClientComm client,ArrayBlockingQueue<String> reqQueue,ArrayBlockingQueue<String> resQueue) {
        this.client = client;
        this.reqQueue = reqQueue;
        this.resQueue = resQueue;
    }
    @Override
    public void run() { 
        try{
            client.start(); //Start Socket
            while (true) { //Long connection to the server
                //System.out.println("looping");
                if (!client.listen()) {
                    break;
                }
                try{Thread.sleep(Const.getTick());} catch (Exception exc){}
            }
            client.stop(); //Close Socket
        } catch(Exception err) {
            err.printStackTrace();
        }
    }
}

class ClientComm{
    ClientNetworkConst Const = new ClientNetworkConst();
    String SERVER_ADRESS = Const.getServerAddress();
    int PORT = Const.getPort();
    ArrayBlockingQueue<String> reqQueue;
    ArrayBlockingQueue<String> resQueue;

    Socket clientSocket;
    PrintWriter output;    
    BufferedReader input;
    ClientComm(ArrayBlockingQueue<String> reqQueue,ArrayBlockingQueue<String> resQueue) {
        this.reqQueue = reqQueue;
        this.resQueue = resQueue;
    }

    public void start() throws Exception{ 
        //create a socket with the local IP address and attempt a connection
        System.out.println("Attempting to establish a connection ...");
        try{
        clientSocket = new Socket(SERVER_ADRESS, PORT);
        output = new PrintWriter(clientSocket.getOutputStream());
        input = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
        //Reciever
        Thread reciverThread = new Thread(new Reciever(resQueue, input),"SocketReciver");
        reciverThread.start();
        System.out.println("Connected to the server");
        } catch(Exception err) {
            System.out.println("Server NOT REACHABLE");
            resQueue.add("404&Server_not_found");
            // err.printStackTrace();
        }
    }

    public Boolean listen() throws Exception{
        if (clientSocket.isClosed()) {
            System.out.println("Connection Closed! Porgram Stopped");
            return false;
        }
        if (!clientSocket.isConnected()) {
            System.out.println("Connection Lost! Trying to reconnect!!!");
            this.start();
            if (this.listen()) {
                System.out.println("Connection Lost! reconnecting...");
                return true;
            }
            return false;
        }
        
        if (reqQueue.isEmpty()) {return true;}
        output.println(reqQueue.remove());
        output.flush();
        return true;
    }
/*
    public void processRes(String res) {
        if (res.equals("")) {return;}
        String[] firstSplit = res.split(Const.getFstRegex());
        String header = firstSplit[0];
        if (header.equals(Const.getReqNorm())) {
            //update other player's position
            String[] secondSplit = firstSplit[1].split(Const.getSecRegex());
            
            return;
        } else 
        if (header.equals(Const.getReqLogin())) {
            resQueue.add(res);
            return;
        } else 
        if (header.equals(Const.getReqAttack())) {
            //203&health-value-decrease
            
            return;
        } else
        if (header.equals(Const.getReqRay())) { //Queue the bullet rays and leave it to broadcast
            //202&X Y fromX fromY BulletID&X Y fromX fromY BulletID&X Y fromX fromY BulletID?
            //Animate BulletRays
            return;
        }
    }
*/
    public void stop() throws Exception{ 
        System.out.println("Socket disconnected");
        input.close();
        output.close();
        clientSocket.close();
    }
}

class Reciever extends Thread{
    ArrayBlockingQueue<String> resQueue;
    BufferedReader input;
    Reciever(ArrayBlockingQueue<String> resQueue, BufferedReader input) {
        this.resQueue = resQueue;
        this.input = input;
    }
    @Override
    public void run() {
        while(true){
            try{
                String res = input.readLine();
                resQueue.add(res);
            } catch(IOException e) {
                e.printStackTrace();
            }
        }
    }
}
